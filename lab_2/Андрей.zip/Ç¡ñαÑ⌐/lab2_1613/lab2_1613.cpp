#include <iostream>
#include <algorithm>
using namespace std;
int main() {
	pair <long long, int> P[200000];
	int N;
	cin >> N;
	for (int iter = 0; iter < N; ++iter)  cin >> P[iter].first;
	for (int iter = 0; iter < N; ++iter) P[iter].second = iter;
	sort(P, P + N);
	int K;
	cin >> K;
	for (int iter = 0; iter < K; ++iter) {
		long long L, R, have;
		cin >> L >> R >> have;
		L--;
		R--;
		int l = -1, r = N;
		while (r - l > 1) {
			long long m = (l + r) / 2;
			if (P[m].first < have) l = m;
			else r = m;
		}
		int Left = r;
		if (P[r].first != have) {
			cout << 0;
			continue;
		}
		l = -1, r = N;
		while (r - l > 1) {
			long long h = (l + r) / 2;
			if (P[h].first <= have) l = h;
			else r = h;
		}
		int Right = l, ans = 0;
		l = Left - 1, r = Right + 1;
		while (r - l > 1) {
			long long h = (r + l) / 2;
			if (P[h].second < L) l = h;
			else {
				if (P[h].second > R) r = h;
				else {
					ans = 1;
					break;
				}
			}
		}
		cout << ans;
	}
}