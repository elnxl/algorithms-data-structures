#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
using namespace std;
typedef long long ll;
struct Q {
	int left, right;
	char ch;
};
const int MAXSIZE = 6000;
Q ms[MAXSIZE];
int n;
vector<int> PT;
unordered_map<int, bool> was;
vector<Q> colorsFinal;
const int END = 1e9;
int main() {
	cin >> n;
	ms[0] = { 0, END, 'w' };
	for (int iter = 1; iter <= n; ++iter) cin >> ms[iter].left >> ms[iter].right >> ms[iter].ch;
	for (int iter = 0; iter <= n; ++iter) {
		if (!was[ms[iter].left]) {
			PT.push_back(ms[iter].left);
			was[ms[iter].left] = 1;
		}
		if (!was[ms[iter].right]) {
			PT.push_back(ms[iter].right);
			was[ms[iter].right] = 1;
		}
	}
	sort(PT.begin(), PT.end());
	for (int i = 0; i < PT.size() - 1; ++i) {
		int l = PT[i], r = PT[i + 1];
		for (int j = n; j >= 0; --j) {
			if (ms[j].left <= l && ms[j].right >= r) {
				colorsFinal.push_back({ l, r, ms[j].ch });
				break;
			}
		}
	}
	int ansLeft = -1, ansRight = -1, answer = 0, currentLen = 0;
	char currentColor = 0;
	int sermStart = colorsFinal[0].left;
	for (int iter = 0; iter < colorsFinal.size(); ++iter) {
		if (colorsFinal[iter].ch == currentColor) currentLen += (colorsFinal[iter].right - colorsFinal[iter].left);
		else {
			if (currentLen > answer&& currentColor == 'w') {
				answer = currentLen, ansLeft = sermStart;
				ansRight = colorsFinal[iter].left;
			}
			currentColor = colorsFinal[iter].ch;
			sermStart = colorsFinal[iter].left;
			currentLen = colorsFinal[iter].right - colorsFinal[iter].left;
		}
	}
	if (currentLen > answer && currentColor == 'w') {
		answer = currentLen;
		ansLeft = sermStart;
		ansRight = END;
	}
	cout << ansLeft << " " << ansRight;
	return 0;
}