#include <iostream>
#include <vector>
using namespace std;
typedef long long ll;
const int N = 300100;
ll M, st[N], a[N], n, q;
ll SUM(int f) {
	f++;
	ll answer = 0;
	while (f > 0) { answer += st[f]; f &= f - 1; }
	return answer;
}
void ADD(int y, ll d) {
	y++;
	while (y <= N) { st[y] += d; y |= y - 1; y++; }
}
int main() {
	cin >> n;
	for (int iter = 0; iter < n; ++iter) cin >> a[iter];
	cin >> q;
	for (int iter = 0; iter < q; ++iter) {
		int t;
		cin >> t;
		if (t == 1) {
			int cur;
			cin >> cur;
			ll answer = a[cur - 1];
			for (int y = 1; y * y <= cur; y++) {
				if (cur == y * y) answer += SUM(y);
				else if (cur % y == 0) answer += SUM(y) + SUM(cur / y);
			}
			cout << answer << "\n";
		} else {
			int l, r, d;
			cin >> l >> r >> d;
			r++;
			ADD(l, d);
			ADD(r, -d);
		}
	}
}