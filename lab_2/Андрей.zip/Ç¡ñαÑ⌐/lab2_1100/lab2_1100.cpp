#include <iostream>
#include <algorithm>

const int K = 1000001;
int First[K], Second[K], Third[K];

bool comp(int x, int y)
{
	if (Second[x] != Second[y]) return Second[x] > Second[y];
	else return x < y;
}

int main()
{
	int k;
	std::cin >> k;
	for (int i = 0; i < k; i++) std::cin >> First[i] >> Second[i];
	for (int i = 0; i < k; i++) Third[i] = i;
	std::sort(Third, Third + k, comp);
	for (int i = 0; i < k; i++) std::cout << First[Third[i]] << " " << Second[Third[i]] << std::endl;
	return 0;
}