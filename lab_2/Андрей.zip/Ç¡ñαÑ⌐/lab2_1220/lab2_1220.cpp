#include <iostream>
#include <map>
#include <stack>
#include <string>
using namespace std;
map <int, stack <int> > cur;
int main() {
	int n;
	cin >> n;
	for (int j = 0; j < n; j++) {
		string str;
		cin >> str;
		if (str == "PUSH") {
			int x, y;
			cin >> x >> y;
			cur[x].push(y);
		} else {
			int a;
			cin >> a;
			cout << cur[a].top() << "\n";
			if (cur[a].size() == 1) cur.erase(a);
			else cur[a].pop();
		}
	}
}