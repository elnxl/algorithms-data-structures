#include <iostream>
#include <set>
using namespace std;
int main() {
	const int M = 30000;
	int N, all = 0, th, l, r;
	set <pair <int, int> > s;
	pair <int, int> p[M];
	cin >> N;
	l = 0;
	r = N - 1;
	while (cin >> th) {
		if (th == -1) break;
		p[all].second = all;
		p[all].first = th;
		all++;
	}
	for (int i = l; i <= r; ++i) s.insert({ p[i].first, p[i].second });
	cout << (*--s.end()).first << endl;
	for (int iter = r + 1; iter < all; ++iter) {
		s.erase({ p[l].first, p[l].second });
		s.insert({ p[r + 1].first, p[r + 1].second });
		l++;
		r++;
		cout << (*--s.end()).first << endl;
	}
}