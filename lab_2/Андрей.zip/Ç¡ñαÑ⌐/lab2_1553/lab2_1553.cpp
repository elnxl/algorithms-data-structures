#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long ll;
const int N = 100100;
const int inf = 1e9;
int n, m, h;
vector <int> v[N];
vector <int> e;
int t[400100], zX[N], niixt[N], pr[N], inp[N], viv[N], pwT[N][30], tt;
void dfs(int a, int b = -1) {
	zX[a] = 1;
	for (auto y : v[a])
		if (y != b) { dfs(y, a); zX[a] += zX[y]; }
	for (int i = 0; i < (int)(v[a]).size(); i++) {
		if (v[a][i] != b)
			if (v[a][0] == b || zX[v[a][0]] < zX[v[a][i]])
				swap(v[a][0], v[a][i]);
	}
}
void hld(int x, int p = -1) {
	inp[x] = (int)(e).size();
	e.push_back(x);
	pr[x] = p;
	niixt[x] = x;
	if (p == -1)
		pr[x] = x;
	else if (2 * zX[x] >= zX[p])
		niixt[x] = niixt[p];
	for (auto y : v[x])
		if (y != p)
			hld(y, x);
	viv[x] = e.size() - 1;
}
void ADDSMT(int v, int l, int r, int pos, int x)
{
	if (r - l == 1) { t[v] += x; return;}
	int c = (l + r) / 2;
	if (pos < c) ADDSMT(2 * v, l, c, pos, x);
	else ADDSMT(2 * v + 1, c, r, pos, x);
	t[v] = max(t[2 * v], t[2 * v + 1]);
}
int GET1(int v, int l, int r, int L, int R) {
	if (L >= r || l >= R) return -inf;
	if (r == R && l == L) return t[v];
	int c = (l + r) / 2;
	return max(GET1(2 * v, l, c, L, min(c, R)), GET1(2 * v + 1, c, r, max(c, L), R));
}
bool ch(int x, int y) {
	return inp[x] <= inp[y] && viv[x] >= viv[y];
}
int lca(int x, int y)
{
	if (ch(x, y))
		return x;
	if (ch(y, x))
		return y;
	for (int i = 19; i >= 0; i--)
	{
		int z = pwT[x][i];
		if (!ch(z, y))
			x = z;
	}
	return pwT[x][0];
}
int jump(int x, int z)
{
	int ans = 0;
	while (inp[niixt[x]] > inp[z])
	{
		ans = max(ans, GET1(1, 0, h, inp[niixt[x]], inp[x] + 1));
		x = pr[niixt[x]];
	}
	ans = max(ans, GET1(1, 0, h, inp[z], inp[x] + 1));
	return ans;
}
int getans(int x, int y)
{
	int z = lca(x, y);
	return max(jump(x, z), jump(y, z));
}
int main() {
	cin >> n;
	for (int i = 0; i < n - 1; ++i)
	{
		int x, y;
		cin >> x >> y;
		x--;
		y--;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	dfs(0);
	hld(0);
	for (int i = 0; i < n; ++i) pwT[i][0] = pr[i];
	for (int i = 1; i < 20; i++)
		for (int j = 0; j < n; j++)
			pwT[j][i] = pwT[pwT[j][i - 1]][i - 1];
	cin >> m;
	h = 1;
	while (h < n) h *= 2;
	for (int i = 0; i < m; ++i) {
		int x, y;
		char c;
		cin >> c >> x >> y;
		if (c == 'I') { x--; ADDSMT(1, 0, h, inp[x], y); }
		else { x--; y--; cout << getans(x, y) << "\n"; }
	}
	return 0;
}