#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
const int N = 20100, M = 30;
vector <int> v[N];
int was[N], d[N], a, b, n, P1[M][N], P2[M][N];
void DFS1(int e) {
	was[e] = 1;
	for (auto w : v[e]) {
		if (!was[w]) {
			d[w] = d[e] + 1;
			DFS1(w);
		}
	}
}
void DFS2(int e) {
	was[e] = 1;
	for (auto w : v[e])	{
		if (!was[w]) {
			DFS2(w);
			P1[0][w] = e;
		}
	}
}
void DFS3(int e) {
	was[e] = 1;
	for (auto w : v[e]) {
		if (!was[w]) {
			DFS3(w);
			P2[0][w] = e;
		}
	}
}
int GET1(int l, int r) {
	int t = 0;
	while (r > 0) {
		if (r % 2) l = P1[t][l];
		t++;
		r /= 2;
	}
	return l;
}
int GET2(int l, int r) {
	int t = 0;
	while (r > 0) {
		if (r % 2) l = P2[t][l];
		t++;
		r /= 2;
	}
	return l;
}
int main() {
	int t;
	cin >> n >> t;
	for (int iter = 0; iter < (n - 1); iter++) {
		int x;
		int y;
		cin >> x >> y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	DFS1(1);
	int MAX1 = 0;
	for (int iter = 1; iter <= n; iter++) {
		if (d[iter] > MAX1) {
			MAX1 = d[iter];
			a = iter;
		}
	}
	for (int iter = 1; iter <= n; iter++) {
		was[iter] = 0;
		d[iter] = 0;
	}
	DFS1(a);
	MAX1 = 0;
	for (int iter = 1; iter <= n; iter++) {
		if (d[iter] > MAX1) {
			MAX1 = d[iter];
			b = iter;
		}
	}
	for (int iter = 1; iter <= n; iter++) was[iter] = 0;
	DFS2(a);
	for (int iter = 1; iter <= n; iter++) was[iter] = 0;
	DFS3(b);
	for (int iter = 1; iter <= 20; iter++) {
		for (int jIter = 1; jIter <= n; jIter++) {
			P1[iter][jIter] = P1[iter - 1][P1[iter - 1][jIter]];
			P2[iter][jIter] = P2[iter - 1][P2[iter - 1][jIter]];
		}
	}
	for (int iter = 0; iter < t; iter++) {
		int x, r;
		cin >> x >> r;
		cout << max(GET1(x, r), GET2(x, r)) << "\n";
	}
	return 0;
}