#include <iostream>
#include <vector>
using namespace std;
int main() {
	vector <char> V;
	string S;
	cin >> S;
	for (int iter = 0; iter < (int)S.size(); iter++) 
		if (V.empty() || V.back() != S[iter]) V.push_back(S[iter]);
		else V.pop_back();
	for (auto iter : V)	cout << iter;
	return 0;
}