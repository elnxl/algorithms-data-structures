#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
using namespace std;
int n, m;
stack <pair <int, int>> akLL;
vector <pair <int, pair <int, int> > > V;
pair <int, pair <int, int> > ehP[200100];
int main() {
	cin >> n;
	for (int i = 0; i < n; i++) {
		int x, y;
		cin >> x >> y;
		ehP[2 * i] = { x, {0, i + 1}};
		ehP[2 * i + 1] = { y, {1, -i - 1} };
	}
	cin >> m;
	sort(ehP, ehP + 2 * n);
	for (int i = 0; i < n * 2; i++) {
		V.push_back(ehP[i]);
		akLL.push(ehP[i].second);
		if (ehP[i].second.first == 1) {
			akLL.pop();
			akLL.pop();
			if (!akLL.empty()) {
				pair <int, int > k = akLL.top();
				V.push_back(make_pair(ehP[i].first, make_pair(2, k.second)));
			}
		}
	}
	for (int i = 0; i < m; ++i) {
		int x;
		cin >> x;
		int k = lower_bound(V.begin(), V.end(), make_pair(x, make_pair(0, 999999999))) - V.begin();
		if (k < 2 * n && V[k].second.first == 1) {
			cout << -V[k].second.second << "\n";
			continue;
		} else {
			k--;
			if (k >= 0 && V[k].second.first != 1) {
				cout << V[k].second.second << "\n";
				continue;
			}
		}
		cout << -1 << "\n";
	}
}