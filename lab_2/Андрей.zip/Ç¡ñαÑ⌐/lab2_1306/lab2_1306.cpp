#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;
int main() {
	int n;
	cin >> n;
	vector<int> V(n);
	for (int i = 0; i < n; i++) cin >> V[i];
	sort(V.begin(), V.end());
	if (n % 2) cout << V[n / 2];
	else cout << fixed << setprecision(1) << ((double)V[n / 2 - 1] + (double)V[n / 2]) / 2;
}