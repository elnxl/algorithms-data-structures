#include <iostream>
#include <vector>
using namespace std;
const int N = 50001, R = 20;
long long cv1[N], cv2[N], T, dt[N], k, prK[N], p[R][N], n, m, was[N];
vector <pair <long long, long long> > v[N];
void dfs(int fi, int se)
{
	cv1[fi] = T++;
	prK[fi] = se;
	was[fi] = 1;
	for (int i = 0; i < v[fi].size(); i++)
		if (!was[v[fi][i].first]) {
			int y = v[fi][i].first;
			dt[y] = dt[fi] + v[fi][i].second;
			if (y == 0) continue;
			else dfs(y, fi);
		}
	cv2[fi] = T++;
}
int ch(int a, int b) {
	return cv1[a] >= cv1[b] && cv2[a] <= cv2[b];
}
int lca(int x, int y)
{
	if (ch(x, y)) return y;
	if (ch(y, x)) return x;
	for (int i = k; i >= 0; i--) {
		int x0 = p[i][x];
		if (!ch(y, x0)) x = x0;
	}
	return prK[x];
}
int main() {
	cin >> n;
	int x, y, w;
	for (int i = 0; i < n - 1; i++) {
		cin >> x >> y >> w;
		v[x].push_back(make_pair(y, w));
		v[y].push_back(make_pair(x, w));
	}
	dt[0] = 0;
	dfs(0, 0);
	int h = 1;
	while (h <= n) {
		h *= 2;
		k++;
	}
	for (int i = 0; i < n; i++) p[0][i] = prK[i];
	for (int i = 1; i <= k; i++)
		for (int j = 0; j < n; j++)
			p[i][j] = p[i - 1][p[i - 1][j]];
	cin >> m;
	for (int i = 0; i < m; i++) {
		int a, b;
		cin >> a >> b;
		int z = lca(a, b);
		cout << dt[a] + dt[b] - 2 * dt[z] << endl;
	}
	return 0;
}