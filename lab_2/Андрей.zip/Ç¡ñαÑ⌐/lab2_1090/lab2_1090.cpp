#include <iostream>
#include <vector>
using namespace std;
typedef long long ll;
int mergeSort(vector<int>& vect, vector<int>& H, int L, int R) {
	if (L == R) return 0;
	int m = (L + R) / 2, cnt_inv = mergeSort(vect, H, L, m) + mergeSort(vect, H, m + 1, R);
	int p1 = L, p2 = m + 1, pos_res = L;
	while (p1 <= m && p2 <= R) {
		if (vect[p1] > vect[p2]) {
			H[pos_res++] = vect[p2++];
			cnt_inv += (m - p1 + 1);
		}
		else H[pos_res++] = vect[p1++];
	}
	for (int i = p1; i <= m; ++i) H[pos_res++] = vect[i];
	for (int i = p2; i <= R; ++i) H[pos_res++] = vect[i];
	for (int i = L; i <= R; ++i) vect[i] = H[i];
	return cnt_inv;
}
int main() {
	int n, k;
	cin >> n >> k;
	int answer = 0, answerPos = 1;
	for (int i = 0; i < k; ++i) {
		vector<int> V;
		V.resize(n);
		for (int j = 0; j < n; ++j) cin >> V[j];
		vector<int> b = V;
		int res = mergeSort(V, b, 0, V.size() - 1);
		if (res > answer) {
			answer = res;
			answerPos = i + 1;
		}
	}
	cout << answerPos;
	return 0;
}