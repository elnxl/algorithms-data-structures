#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 32100, M = 20000;
int n, jJ[N], ans[M];
pair <int, int> p[M];
ll f1(int x) {
	x++;
	ll ans = 0;
	while (x > 0)
	{
		ans += jJ[x];
		x &= x - 1;
	}
	return ans;
}
void f2(int q, ll d) {
	q++;
	while (q <= N)
	{
		jJ[q] += d;
		q |= q - 1;
		q++;
	}
}
int main() {
	cin >> n;
	for (int iter = 0; iter < (n); iter++) cin >> p[iter].first >> p[iter].second;
	sort(p, p + n);
	for (int iter = 0; iter < (n); iter++) {
		f2(p[iter].second + 1, 1);
		ans[f1(p[iter].second + 1)]++;
	}
	for (int iter = 0; iter < (n); iter++) cout << ans[iter + 1] << "\n";
	return 0;
}