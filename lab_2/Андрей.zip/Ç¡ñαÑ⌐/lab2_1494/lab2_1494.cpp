#include <iostream>
using namespace std;
int main() {
	const int K = 100500;
	int inp[K], ball[K];
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) cin >> inp[i];
	int i = 0, j = -1;
	for (int thisBall = 1; thisBall <= n; ++thisBall) {
		if (i >= n) break;
		if (j < 0) j = -1;
		j++;
		ball[j] = thisBall;
		while (inp[i] == ball[j]) {
			if (i >= n || j < 0) break;
			i++;
			j--;
		}
	}
	if (j < 0) cout << "Not a proof";
	else cout << "Cheater";
}